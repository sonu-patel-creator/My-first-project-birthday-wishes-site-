/* ============================================================
   Birthday Site — script.js
   All data lives in localStorage. No backend involved.
   Keys used:
     bday_settings  -> {name, message, date, video}
     bday_gallery   -> [{url, caption}]
     bday_guestbook -> [{name, message, date}]
     bday_wishlist  -> [{item, link, claimed}]
   ============================================================ */

const STORAGE_KEYS = {
  settings: 'bday_settings',
  gallery: 'bday_gallery',
  guestbook: 'bday_guestbook',
  wishlist: 'bday_wishlist',
};

const DEFAULTS = {
  settings: {
    name: "Someone's Birthday",
    message: "Set the name, date and message from the Admin page.",
    date: '', // ISO datetime-local string
    video: '',
  },
  gallery: [
    { url: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=1200&q=80', caption: 'Balloons everywhere' },
    { url: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=1200&q=80', caption: 'Cake time' },
    { url: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?w=1200&q=80', caption: 'Party lights' },
  ],
  guestbook: [],
  wishlist: [
    { item: 'A good book', link: '', claimed: false },
    { item: 'Bluetooth speaker', link: '', claimed: false },
  ],
};

// ---------- storage helpers ----------
function loadData(key) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return structuredClone(DEFAULTS[shortKey(key)]);
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to read', key, e);
    return structuredClone(DEFAULTS[shortKey(key)]);
  }
}
function shortKey(fullKey) {
  return Object.keys(STORAGE_KEYS).find(k => STORAGE_KEYS[k] === fullKey);
}
function saveData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

// ---------- load all data ----------
const settings = loadData(STORAGE_KEYS.settings);
const gallery = loadData(STORAGE_KEYS.gallery);
let guestbook = loadData(STORAGE_KEYS.guestbook);
let wishlist = loadData(STORAGE_KEYS.wishlist);

// ============================================================
// HERO
// ============================================================
document.getElementById('heroName').textContent = settings.name || DEFAULTS.settings.name;
document.getElementById('heroMessage').textContent = settings.message || DEFAULTS.settings.message;

// ============================================================
// COUNTDOWN
// ============================================================
function tickCountdown() {
  const target = settings.date ? new Date(settings.date).getTime() : null;
  const els = {
    days: document.getElementById('cd-days'),
    hours: document.getElementById('cd-hours'),
    mins: document.getElementById('cd-mins'),
    secs: document.getElementById('cd-secs'),
  };
  const doneMsg = document.getElementById('countdownDone');
  const countdownBox = document.getElementById('countdown');

  if (!target) {
    els.days.textContent = '--';
    els.hours.textContent = '--';
    els.mins.textContent = '--';
    els.secs.textContent = '--';
    return;
  }

  const now = Date.now();
  const diff = target - now;

  if (diff <= 0) {
    countdownBox.classList.add('hidden');
    doneMsg.classList.remove('hidden');
    clearInterval(window.__cdInterval);
    launchConfetti(); // celebrate automatically once
    return;
  }

  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  const secs = Math.floor((diff % 60000) / 1000);

  els.days.textContent = String(days).padStart(2, '0');
  els.hours.textContent = String(hours).padStart(2, '0');
  els.mins.textContent = String(mins).padStart(2, '0');
  els.secs.textContent = String(secs).padStart(2, '0');
}
tickCountdown();
window.__cdInterval = setInterval(tickCountdown, 1000);

// ============================================================
// CONFETTI
// ============================================================
function launchConfetti() {
  if (typeof confetti !== 'function') return;
  confetti({ particleCount: 140, spread: 80, origin: { y: 0.6 }, colors: ['#F2C14E', '#FF6F91', '#6FCF97', '#F7F1E3'] });
  setTimeout(() => confetti({ particleCount: 80, spread: 120, origin: { y: 0.4 } }), 300);
}
document.getElementById('confettiBtn').addEventListener('click', launchConfetti);

// ============================================================
// SLIDESHOW
// ============================================================
(function initSlideshow() {
  const imgEl = document.getElementById('slideImg');
  const dotsEl = document.getElementById('slideDots');
  const prevBtn = document.getElementById('slidePrev');
  const nextBtn = document.getElementById('slideNext');
  let index = 0;
  let autoTimer;

  const images = gallery.length ? gallery : DEFAULTS.gallery;

  function render() {
    imgEl.src = images[index].url;
    imgEl.alt = images[index].caption || 'gallery image';
    dotsEl.innerHTML = '';
    images.forEach((_, i) => {
      const dot = document.createElement('span');
      if (i === index) dot.classList.add('active');
      dot.addEventListener('click', () => { index = i; render(); restartAuto(); });
      dotsEl.appendChild(dot);
    });
  }

  function next() { index = (index + 1) % images.length; render(); }
  function prev() { index = (index - 1 + images.length) % images.length; render(); }
  function restartAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(next, 5000);
  }

  nextBtn.addEventListener('click', () => { next(); restartAuto(); });
  prevBtn.addEventListener('click', () => { prev(); restartAuto(); });

  render();
  restartAuto();
})();

// ============================================================
// VIDEO FEED
// ============================================================
(function initVideo() {
  const videoEl = document.getElementById('videoFeed');
  const noVideoMsg = document.getElementById('noVideoMsg');
  if (settings.video) {
    videoEl.src = settings.video;
  } else {
    videoEl.classList.add('hidden');
    noVideoMsg.classList.remove('hidden');
  }
})();

// ============================================================
// GUESTBOOK
// ============================================================
function renderGuestbook() {
  const list = document.getElementById('guestList');
  const empty = document.getElementById('guestEmpty');
  list.innerHTML = '';
  if (!guestbook.length) {
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');
  guestbook.slice().reverse().forEach(entry => {
    const li = document.createElement('li');
    const dateStr = new Date(entry.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    li.innerHTML = `<span class="g-name">${escapeHtml(entry.name)}</span><span class="g-date">${dateStr}</span><div class="g-msg">${escapeHtml(entry.message)}</div>`;
    list.appendChild(li);
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

document.getElementById('guestForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('guestName').value.trim();
  const message = document.getElementById('guestMessage').value.trim();
  if (!name || !message) return;
  guestbook.push({ name, message, date: new Date().toISOString() });
  saveData(STORAGE_KEYS.guestbook, guestbook);
  renderGuestbook();
  e.target.reset();
  launchConfetti();
});

renderGuestbook();

// ============================================================
// TRIVIA QUIZ
// ============================================================
const QUIZ_QUESTIONS = [
  { q: 'What does everyone secretly count while singing "Happy Birthday"?', opts: ['The candles', 'Their steps', 'Sheep', 'Calories'], correct: 0 },
  { q: 'Traditionally, what should you do right after blowing out birthday candles?', opts: ['Take a nap', 'Make a wish', 'Do a dance', 'Call your mom'], correct: 1 },
  { q: 'Which of these is NOT a common birthday tradition?', opts: ['Cutting a cake', 'Singing a song', 'Filing taxes', 'Opening presents'], correct: 2 },
];

let quizIndex = 0;
let quizScore = 0;

function renderQuiz() {
  const box = document.getElementById('quizBox');
  const resultEl = document.getElementById('quizResult');
  const restartBtn = document.getElementById('quizRestart');
  resultEl.classList.add('hidden');
  restartBtn.classList.add('hidden');

  if (quizIndex >= QUIZ_QUESTIONS.length) {
    box.innerHTML = '';
    resultEl.textContent = `You scored ${quizScore} / ${QUIZ_QUESTIONS.length} 🎉`;
    resultEl.classList.remove('hidden');
    restartBtn.classList.remove('hidden');
    if (quizScore === QUIZ_QUESTIONS.length) launchConfetti();
    return;
  }

  const current = QUIZ_QUESTIONS[quizIndex];
  box.innerHTML = `
    <p class="quiz-q">${escapeHtml(current.q)}</p>
    <div class="quiz-opts"></div>
    <p class="quiz-progress">Question ${quizIndex + 1} of ${QUIZ_QUESTIONS.length}</p>
  `;
  const optsContainer = box.querySelector('.quiz-opts');
  current.opts.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.textContent = opt;
    btn.addEventListener('click', () => {
      Array.from(optsContainer.children).forEach(b => b.disabled = true);
      if (i === current.correct) {
        btn.classList.add('correct');
        quizScore++;
      } else {
        btn.classList.add('wrong');
        optsContainer.children[current.correct].classList.add('correct');
      }
      setTimeout(() => { quizIndex++; renderQuiz(); }, 900);
    });
    optsContainer.appendChild(btn);
  });
}

document.getElementById('quizRestart').addEventListener('click', () => {
  quizIndex = 0;
  quizScore = 0;
  renderQuiz();
});

renderQuiz();

// ============================================================
// WISHLIST
// ============================================================
function renderWishlist() {
  const list = document.getElementById('wishlist');
  const empty = document.getElementById('wishEmpty');
  list.innerHTML = '';
  if (!wishlist.length) {
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');
  wishlist.forEach((item, i) => {
    const li = document.createElement('li');
    if (item.claimed) li.classList.add('claimed');
    const linkHtml = item.link ? `<a href="${escapeHtml(item.link)}" target="_blank" rel="noopener">view</a>` : '';
    li.innerHTML = `
      <div>
        <div>${escapeHtml(item.item)}</div>
        ${linkHtml}
      </div>
      <button data-i="${i}">${item.claimed ? 'Claimed ✓' : "I've got this"}</button>
    `;
    li.querySelector('button').addEventListener('click', (e) => {
      const idx = Number(e.target.dataset.i);
      wishlist[idx].claimed = !wishlist[idx].claimed;
      saveData(STORAGE_KEYS.wishlist, wishlist);
      renderWishlist();
    });
    list.appendChild(li);
  });
}
renderWishlist();

// ============================================================
// MUSIC TOGGLE
// ============================================================
(function initMusic() {
  const btn = document.getElementById('musicToggle');
  const audio = document.getElementById('bgAudio');
  let playing = false;
  btn.addEventListener('click', () => {
    if (playing) {
      audio.pause();
      btn.textContent = '🔈';
    } else {
      audio.play().catch(() => {});
      btn.textContent = '🔊';
    }
    playing = !playing;
  });
})();
