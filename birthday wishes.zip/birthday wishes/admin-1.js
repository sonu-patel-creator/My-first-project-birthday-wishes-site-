/* ============================================================
   Birthday Site — admin.js
   Simple client-side password gate (NOT real security — anyone
   who reads this file can see the password). It's a deterrent
   for casual visitors, not a security boundary.
   ============================================================ */

const ADMIN_PASSWORD = 'birthday123'; // <-- change this to whatever you like

const STORAGE_KEYS = {
  settings: 'bday_settings',
  gallery: 'bday_gallery',
  guestbook: 'bday_guestbook',
  wishlist: 'bday_wishlist',
};

const DEFAULTS = {
  settings: { name: "Someone's Birthday", message: 'Set the name, date and message from the Admin page.', date: '', video: '' },
  gallery: [
    { url: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=1200&q=80', caption: 'Balloons everywhere' },
    { url: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=1200&q=80', caption: 'Cake time' },
    { url: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?w=1200&q=80', caption: 'Party lights' },
  ],
  guestbook: [],
  wishlist: [
    { item: 'A good book', link: '', claimed: false },
    { item: 'Bluetooth speaker', link: '', claimed: false },
  ],
};

function shortKey(fullKey) { return Object.keys(STORAGE_KEYS).find(k => STORAGE_KEYS[k] === fullKey); }
function loadData(key) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return structuredClone(DEFAULTS[shortKey(key)]);
    return JSON.parse(raw);
  } catch (e) {
    return structuredClone(DEFAULTS[shortKey(key)]);
  }
}
function saveData(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ============================================================
// PASSWORD GATE
// ============================================================
document.getElementById('unlockBtn').addEventListener('click', tryUnlock);
document.getElementById('passwordInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') tryUnlock();
});

function tryUnlock() {
  const val = document.getElementById('passwordInput').value;
  if (val === ADMIN_PASSWORD) {
    document.getElementById('lockScreen').classList.add('hidden');
    document.getElementById('adminPanel').classList.remove('hidden');
    initAdminPanel();
  } else {
    document.getElementById('lockError').classList.remove('hidden');
  }
}

// ============================================================
// ADMIN PANEL
// ============================================================
function initAdminPanel() {
  let settings = loadData(STORAGE_KEYS.settings);
  let gallery = loadData(STORAGE_KEYS.gallery);
  let guestbook = loadData(STORAGE_KEYS.guestbook);
  let wishlist = loadData(STORAGE_KEYS.wishlist);

  // ---- settings form ----
  document.getElementById('setName').value = settings.name || '';
  document.getElementById('setMessage').value = settings.message || '';
  document.getElementById('setDate').value = settings.date || '';
  document.getElementById('setVideo').value = settings.video || '';

  document.getElementById('saveSettings').addEventListener('click', () => {
    settings = {
      name: document.getElementById('setName').value.trim() || DEFAULTS.settings.name,
      message: document.getElementById('setMessage').value.trim(),
      date: document.getElementById('setDate').value,
      video: document.getElementById('setVideo').value.trim(),
    };
    saveData(STORAGE_KEYS.settings, settings);
    flashSaved('settingsSaved');
  });

  function flashSaved(id) {
    const el = document.getElementById(id);
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 1800);
  }

  // ---- gallery management ----
  function renderGallery() {
    const list = document.getElementById('galleryAdminList');
    const empty = document.getElementById('galleryAdminEmpty');
    list.innerHTML = '';
    if (!gallery.length) { empty.classList.remove('hidden'); updateStats(); return; }
    empty.classList.add('hidden');
    gallery.forEach((img, i) => {
      const li = document.createElement('li');
      li.innerHTML = `
        <div class="row-main">
          <img class="thumb" src="${escapeHtml(img.url)}" alt="" onerror="this.style.visibility='hidden'" />
          <div class="text-block">
            <span class="primary">${escapeHtml(img.caption || '(no caption)')}</span>
            <span class="meta">${escapeHtml(img.url)}</span>
          </div>
        </div>
        <button data-i="${i}">Remove</button>`;
      li.querySelector('button').addEventListener('click', () => {
        gallery.splice(i, 1);
        saveData(STORAGE_KEYS.gallery, gallery);
        renderGallery();
      });
      list.appendChild(li);
    });
    updateStats();
  }
  document.getElementById('addImgBtn').addEventListener('click', () => {
    const url = document.getElementById('newImgUrl').value.trim();
    const caption = document.getElementById('newImgCaption').value.trim();
    if (!url) return;
    gallery.push({ url, caption });
    saveData(STORAGE_KEYS.gallery, gallery);
    document.getElementById('newImgUrl').value = '';
    document.getElementById('newImgCaption').value = '';
    renderGallery();
  });
  renderGallery();

  // ---- guestbook moderation ----
  function renderGuestAdmin() {
    const list = document.getElementById('guestAdminList');
    const empty = document.getElementById('guestAdminEmpty');
    list.innerHTML = '';
    if (!guestbook.length) { empty.classList.remove('hidden'); updateStats(); return; }
    empty.classList.add('hidden');
    guestbook.forEach((entry, i) => {
      const li = document.createElement('li');
      li.innerHTML = `
        <div class="row-main">
          <div class="text-block">
            <span class="primary"><strong>${escapeHtml(entry.name)}</strong>: ${escapeHtml(entry.message)}</span>
            <span class="meta">${new Date(entry.date).toLocaleString()}</span>
          </div>
        </div>
        <button data-i="${i}">Delete</button>`;
      li.querySelector('button').addEventListener('click', () => {
        guestbook.splice(i, 1);
        saveData(STORAGE_KEYS.guestbook, guestbook);
        renderGuestAdmin();
      });
      list.appendChild(li);
    });
    updateStats();
  }
  renderGuestAdmin();

  // ---- wishlist management ----
  function renderWishAdmin() {
    const list = document.getElementById('wishAdminList');
    const empty = document.getElementById('wishAdminEmpty');
    list.innerHTML = '';
    if (!wishlist.length) { empty.classList.remove('hidden'); updateStats(); return; }
    empty.classList.add('hidden');
    wishlist.forEach((item, i) => {
      const li = document.createElement('li');
      li.innerHTML = `
        <div class="row-main">
          <div class="text-block">
            <span class="primary">${escapeHtml(item.item)}${item.claimed ? '<span class="badge">Claimed</span>' : ''}</span>
            ${item.link ? `<span class="meta">${escapeHtml(item.link)}</span>` : ''}
          </div>
        </div>
        <button data-i="${i}">Remove</button>`;
      li.querySelector('button').addEventListener('click', () => {
        wishlist.splice(i, 1);
        saveData(STORAGE_KEYS.wishlist, wishlist);
        renderWishAdmin();
      });
      list.appendChild(li);
    });
    updateStats();
  }
  document.getElementById('addWishBtn').addEventListener('click', () => {
    const item = document.getElementById('newWishItem').value.trim();
    const link = document.getElementById('newWishLink').value.trim();
    if (!item) return;
    wishlist.push({ item, link, claimed: false });
    saveData(STORAGE_KEYS.wishlist, wishlist);
    document.getElementById('newWishItem').value = '';
    document.getElementById('newWishLink').value = '';
    renderWishAdmin();
  });
  renderWishAdmin();

  // ---- stat cards ----
  function updateStats() {
    document.getElementById('statGallery').textContent = gallery.length;
    document.getElementById('statGuests').textContent = guestbook.length;
    document.getElementById('statWishlist').textContent = wishlist.length;
    const daysEl = document.getElementById('statDays');
    if (settings.date) {
      const diff = new Date(settings.date).getTime() - Date.now();
      daysEl.textContent = diff > 0 ? Math.ceil(diff / 86400000) : '🎉';
    } else {
      daysEl.textContent = '—';
    }
  }
  updateStats();

  // ---- sidebar scroll-spy ----
  const navLinks = Array.from(document.querySelectorAll('.nav-link'));
  const sections = navLinks.map(l => document.querySelector(l.getAttribute('href'))).filter(Boolean);
  function onScroll() {
    let current = sections[0];
    sections.forEach(sec => {
      if (sec.getBoundingClientRect().top - 100 <= 0) current = sec;
    });
    navLinks.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#' + current.id));
  }
  window.addEventListener('scroll', onScroll);
  onScroll();

  // ---- lock again ----
  document.getElementById('lockAgainBtn').addEventListener('click', () => {
    document.getElementById('adminPanel').classList.add('hidden');
    document.getElementById('lockScreen').classList.remove('hidden');
    document.getElementById('passwordInput').value = '';
    document.getElementById('lockError').classList.add('hidden');
  });

  // ---- clear all data ----
  document.getElementById('clearDataBtn').addEventListener('click', () => {
    const sure = confirm('This will permanently clear all settings, gallery, guestbook and wishlist data stored in this browser. Continue?');
    if (!sure) return;
    Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
    location.reload();
  });
}
